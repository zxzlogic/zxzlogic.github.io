function [ flag_PD, pi, rho, theta ] = LLRT( n, PCoordinates, theta_0,sig_level )
% Log Likelihood Rate Test for Theta

% Input
% n: variable num
% PCoordinates: the joint probability over n variables
% sig_level: the significance level (default 0.02)

% Output
% flag_PD: whether the null hypothesis is rejected or not
% pi: the probability that we belief current pattern is of pure dependence

global docCount;
[theta, g] = theta_n(n,PCoordinates);
if abs(theta) < theta_0,
    s = 0;
else
    s = abs(theta) - theta_0;
end
rho = docCount * g * s^2;

s = sqrt(rho);

pr = 2 * (1 - normcdf(s,0,1));
if pr > sig_level
    flag_PD = 0;
else
    flag_PD = 1;
end
pi = 1-pr;
end
%% calculate the n-order theta coordinate, and its Fisher Information
function [theta, g_dd] = theta_n(n,PCoordinates)
theta = 0;
g_dd = 0;
for i=1:2^n
    binary_i = int2binary(i-1,n);
    nonzero_i = find(binary_i);
    
    if mod(n-length(nonzero_i),2) == 0
        theta = theta + log(PCoordinates(i));
    else
        theta = theta - log(PCoordinates(i));
    end
    g_dd = g_dd + 1/PCoordinates(i);
end
g_dd = 1/g_dd;
end
