function [ PPD_cell ] = MergePPD( selTermNum,maxOrder,pairwisePD )
minCooccur = 5;
PPD_cell = cell(1,maxOrder-1);
PPD_cell{1} = pairwisePD;

% adj_mat: the adjacent matrix between all selected terms, where the edges
%   between two nodes(terms) are defined as the pairwise PPD dependence 
adj_mat = zeros(selTermNum);
temp_ind = sub2ind([selTermNum,selTermNum],pairwisePD(:,1),pairwisePD(:,2));
adj_mat(temp_ind) = 1;
adj_mat = adj_mat + adj_mat';


for i = 2:maxOrder-1
    fprintf('Merging for %d-order PPD\n', i+1);
    PPD_order = []; % store for PPD of order i+1
    PPD_lower = PPD_cell{i-1};% PPD of previous order i
    
    %separate lower-order PPD in to groups, each group shares the same
    %prefix, only the last element is different.
    groups = groupPPD(PPD_lower);
    
    [groupNum, ~] = size(groups);
    for k = 1:groupNum
        if groups(k,1) == groups(k,2)
            continue;
        end
        sub_group = PPD_lower(groups(k,1):groups(k,2),:);
        sub_prefix = sub_group(1,1:end-1);
        
        sub_last = sub_group(:,end);
        sub_pair = nchoosek(sub_last,2);
        [pairNum,~] = size(sub_pair);
        for p = 1:pairNum,
            term_1 = sub_pair(p,1);
            term_2 = sub_pair(p,2);
            % if the current pattern is Pairwise PD and cooccured more than
            % minCooccur times
            if adj_mat(term_1, term_2) == 1 && ...
                    CalculateCooccurrence([sub_prefix,term_1, term_2])>= minCooccur
                PPD_order = [PPD_order;sub_prefix,term_1, term_2];
            end
        end
    end
    PPD_cell{i} = PPD_order;
end
end

function [groups] = groupPPD(PPD_lower)
groups = [];
[N,order] = size(PPD_lower);
if isempty(PPD_lower)
    return;
end
start_i = 1;
end_i = 1;
while end_i <= N
    try_i = end_i+1;
    if end_i == N
        groups = [groups;start_i,end_i];
        break;
    end
    a = PPD_lower(start_i,1:order-1);
    b = PPD_lower(try_i,1:order-1);
    if isempty(find(PPD_lower(start_i,1:order-1)~=PPD_lower(try_i,1:order-1)))
        end_i = try_i;
    else
        groups = [groups;start_i,end_i];
        start_i = end_i+1;
        end_i = start_i;
    end
end
end

