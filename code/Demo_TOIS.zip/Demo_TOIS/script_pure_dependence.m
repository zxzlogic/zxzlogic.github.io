% Mining Pure Dependencies among a set of words
% 1. Input a set of documents (i.e., a corpus)
% 2. Build the inverted document list for all words
% 3. Do Log-likelihood Ratio Test for all candidate word combinations
% 4. Output those combinations that fulfill the requirements for pure
%    dependence, which we call them PURE Patterns

%##############Pre-process: Input & Build Index#######################%
%this pre-processing step could be done by many ways. Here we are using 
%the AP88 corpus, indexed by Lemur toolkit with stemming and stopwords
%removed. Top 100 words weighted by TF*IDF are selected.
selTermNum = 30; % maximumly 100
maxOrder = 4; % the maximum order we want
% The selected terms' ID and Str (top # tf*idf weight)
global selTermID;
global selTermStr;
% The total number of document in corpus
global docCount;
% the i-th row represents the list of documents contain term t_i
global doclist_cell;
doclist_cell = importdata('termDocList.mat');
selTermID = importdata('termID.mat');
selTermID = selTermID(1:selTermNum);
selTermStr = importdata('termStr.mat');
selTermStr = selTermStr(1:selTermNum);
selTermNum = length(selTermID);
docCount = importdata('docCount.mat');


theta_0 = 1;
sig_level = 0.02;
%##############Mining PPD patterns#######################%
%Pairwise Pure Dependence: dependencies within a word combination (w_1,w_2,
%...,w_m) are pairwisely pure (e.g., [w_1, w_2], [w_1, w_3], and etc). 
% PPD_S1: LLRT test for all word pairs
wordPair = nchoosek(1:selTermNum,2);
[pairNum,~] = size(wordPair);
pairwisePD_flag = zeros(1,pairNum);
fprintf('Starting to Generate Pair PD\n');
for i=1:pairNum
   this_P = CalculateP( doclist_cell(wordPair(i,:)), 2 );
   [ flag_PD, pi, rho, theta ] = LLRT( 2, this_P, theta_0,sig_level );
   pairwisePD_flag(i) = flag_PD;
   if mod(i,floor(pairNum/20))==0
       fprintf('Progress >> %.2f \n',i/pairNum);
   end
end
pairwisePD = wordPair(find(pairwisePD_flag),:);
fprintf('Done Generating Pair PD\n');
% PPD_S2: Merging Lower-order PPD Patterns into Higher-order
fprintf('Starting to Merge Pair PD\n');
[ PPD_cell ] = MergePPD(selTermNum, maxOrder,pairwisePD );
fprintf('Done Merging Pair PD\n');

fprintf('PPD patterns: from %d-order to %d-order\n',2,maxOrder);
showPatterns(PPD_cell);
fprintf('-----------------------------------------------------\n');

%##############Mining TPD patterns#######################%
%Theta Pure Dependence: for a word combination (w_1,w_2,...,w_m), do LLRT
%for the m-order theta. If the null hypothesis is rejected, then it is of
%pure dependence.

%TPD_S1: the PPDs mined before are used as candidates for TPD patterns
% Or you can try other candidate settings.
fprintf('Using the PPD as candidates\n');
%TPD_S2: LLRT for each candidates
theta_0 = 1;
sig_level = 0.02;
TPD_cell = cell(1,maxOrder-1);
for i = 1:length(PPD_cell)
    PPD_candidate = PPD_cell{i};
    [row, col] = size(PPD_candidate);
    fprintf('Starting LLRT for %d-order TPD\n', col);
    if col == 2
        TPD_cell{1} = PPD_candidate;
        continue;
    end
    TPD_order = [];
    for r = 1:row
        termList = PPD_candidate(r,:);
        this_P = CalculateP( doclist_cell(termList), col );
        [ flag_PD, pi, rho, theta ] = LLRT( col, this_P, theta_0,sig_level );
        if flag_PD
            TPD_order = [TPD_order;termList];
        end
    end
    TPD_cell{i} = TPD_order;
end
fprintf('Done LLRT for TPD\n');

fprintf('TPD patterns: from %d-order to %d-order\n',2,maxOrder);
showPatterns(TPD_cell);
fprintf('-----------------------------------------------------\n');


