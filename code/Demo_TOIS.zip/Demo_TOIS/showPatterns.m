function showPatterns(PD_cell)
global selTermStr
K = length(PD_cell);
for k=1:K
    this_PD = PD_cell{k};
    if isempty(this_PD)
        continue;
    end
    [row, ~] = size(this_PD);
    for i = 1:row
        disp(selTermStr(this_PD(i,:)));
    end
end
end

