function [ i ] = binary2int(binary_i)
    n = length(binary_i);
    i=0;
    for j = 1 : n
        if binary_i(j) == 1
            i=i+2^(j-1);
        end
    end
end