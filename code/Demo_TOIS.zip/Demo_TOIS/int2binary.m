function [ binary_i ] = int2binary(i, n)
    binary_i = zeros(n, 1);
    for j = 1 : n
        if(mod(i, 2) == 0)
            binary_i(j, 1) = 0;
        else
            binary_i(j, 1) = 1;
        end
        i = floor(i / 2);
    end
end