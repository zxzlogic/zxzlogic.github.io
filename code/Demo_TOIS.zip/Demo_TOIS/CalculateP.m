function [ PCoordinates ] = CalculateP( docLists, n )
% for example: n=2, the joint probability (p_11, p_10, p_01, p_00) of two different terms: t_i and t_j
%    p_11 is computed as: #(documents contain both t_i and t_j) / #(total documents)
%    p_10 is computed as: #(documents contain t_i but no t_j) / #(total documents)
%    p_01 is computed as: #(documents contain t_j but no t_i) / #(total documents)
%    p_00 is computed as: #(documents contain neither t_i nor t_j) / #(total documents)
global docCount;
unionAll = [];
PCoordinates = zeros(1,2^n);
for i = 1:n
    unionAll = union(docLists{i},unionAll);
end
for i=1:2^n-1
    binary_i = int2binary(i,n);
    joint_doclist = unionAll;
    for bit_j = 1:n
        if binary_i(bit_j) == 0
            joint_doclist = setdiff(joint_doclist,docLists{bit_j});
        else
            joint_doclist = intersect(joint_doclist,docLists{bit_j});
        end
    end
    PCoordinates(i+1)=length(joint_doclist);
end
PCoordinates(1) = docCount - length(unionAll);
PCoordinates = (PCoordinates+0.5)./docCount;
end

