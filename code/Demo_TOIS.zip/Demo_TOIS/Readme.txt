text dataset: TREC AP88
Candidate terms: top 100 TFIDF terms

Parameters:
1. selTermNum: select top selTermNum terms from the total 100 candidate terms.
2. maxOrder: the maximum order of word patterns that are extracted
3. theta_0 = 1; sig_level = 0.02; Used in the Log-likelihood ratio test, theta_0 is used to control
the threshold for the statistics theta and sig_level is the significant level in the hypothesis test.

Run the script: script_pure_dependence.m
Output: the Pair-wise pure dependence and Theta pure dependence, in each order