function [ df ] = CalculateCooccurrence( termList )
global doclist_cell
n = length(termList);
docLists = doclist_cell(termList(:));
joint_doclist = docLists{1};
if n==1
    df = length(joint_doclist);
    return;
end
for i = 2:n
    joint_doclist = intersect(joint_doclist,docLists{i});
end
df = length(joint_doclist);
end

